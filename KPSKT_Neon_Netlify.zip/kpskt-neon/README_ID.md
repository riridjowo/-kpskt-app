# KPSKT — paket integrasi Neon + Netlify

Paket ini mempertahankan tampilan aplikasi KPSKT dan mengganti penyimpanan formulir/riwayat dari `localStorage` ke Neon PostgreSQL melalui Netlify Function.

## Penting sebelum dipakai
- Ini adalah paket sumber untuk deploy, bukan situs yang sudah terpasang otomatis.
- `DATABASE_URL` harus diisi di Netlify dengan connection string Neon (jangan dibagikan).
- Fungsi server harus ikut ter-deploy. Upload HTML saja lewat Netlify Drop tidak cukup untuk menjalankan Netlify Functions. Deploy paket ini melalui repository Git yang terhubung ke Netlify atau Netlify CLI.
- WhatsApp API hanya aktif setelah Meta Cloud API siap, token dan Phone Number ID dimasukkan sebagai environment variables, serta template WhatsApp berbahasa Indonesia telah disetujui Meta.

## 1. Buat tabel di Neon
Buka Neon → SQL Editor, lalu jalankan seluruh isi `schema.sql` satu kali.

## 2. Siapkan Environment Variables di Netlify
Di Project configuration → Environment variables, tambahkan:

- `DATABASE_URL` = connection string Neon (gunakan pooled connection string)
- `KPSKT_ADMIN_USERNAME` = `admin` (atau username pilihan)
- `KPSKT_ADMIN_PASSWORD` = password admin yang kuat dan unik
- `KPSKT_SESSION_SECRET` = string acak panjang minimal 32 karakter

Opsional untuk WhatsApp Cloud API:
- `WHATSAPP_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `WHATSAPP_GRAPH_VERSION` = `v22.0` (sesuaikan dengan versi Graph API yang aktif di aplikasi Meta)
- `WHATSAPP_ADMIN_NUMBER` = nomor admin format internasional, contoh `62812xxxxxxx`
- `WHATSAPP_REGISTRATION_TEMPLATE` = nama template yang telah disetujui Meta untuk notifikasi admin
- `WHATSAPP_SCHEDULE_TEMPLATE` = nama template yang telah disetujui Meta untuk jadwal steril

Jangan pernah memasukkan token ke HTML, repo publik, atau chat.

## 3. Deploy
Hubungkan folder/repository ini ke situs Netlify. Build settings:
- Build command: kosong (atau `npm install` bila diminta)
- Publish directory: `.`
- Functions directory: `netlify/functions`

Setelah deploy, tes `https://NAMA-SITUS/.netlify/functions/kpskt-api?action=...` hanya melalui aplikasi; jangan mempublikasikan URL berisi rahasia.

## 4. Login admin
Login memakai `KPSKT_ADMIN_USERNAME` dan `KPSKT_ADMIN_PASSWORD` yang diatur di Netlify. Password demo lama tidak lagi digunakan.

## 5. WhatsApp
- Pendaftaran baru akan mencoba mengirim template notifikasi ke nomor admin jika variabel WhatsApp lengkap.
- Tombol **Kirim otomatis** di bagian kloter memanggil template jadwal untuk nomor pemilik.
- Nama template dan jumlah/urutan variabel harus cocok persis dengan template yang disetujui di WhatsApp Manager. Jika template belum disetujui, pengiriman akan gagal.
- Pastikan pemilik memberi persetujuan menerima pesan WhatsApp KPSKT. Di luar jendela layanan 24 jam, pesan bisnis yang dimulai oleh bisnis memerlukan template yang disetujui.

## Catatan keamanan dan pengujian
- Endpoint pendaftaran publik hanya menerima data yang divalidasi; data admin memerlukan sesi bertanda tangan.
- Penghapusan data bersifat permanen.
- Lakukan uji dengan data fiktif dahulu. Pastikan data pendaftar terlihat dari dua perangkat sebelum membuka pendaftaran umum.
- Paket ini tidak memindahkan data lama yang mungkin tersimpan di browser perangkat sebelumnya.
